# Privacy Policy - Driver App

Projeto de teste. O app armazena localmente ofertas simuladas. Nenhum dado pessoal é transmitido por este pacote de exemplo.
