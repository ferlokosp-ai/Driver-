1. Push repo to GitHub
2. Actions -> Run workflow -> download artifact
